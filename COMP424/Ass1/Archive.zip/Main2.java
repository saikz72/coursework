import java.util.*;

public class Main2 {
	public static void main(String args[]) {
		Search.bruteForceSearch100Instances();
		Search.random100Instance();
		Search.hillClimbingSearch100Instances();

	}
}
